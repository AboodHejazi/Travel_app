import './styles/style.scss';
console.log('Webpack Setup Works!');

import './js/app.js';
